<?php

 include 'db_connect.php';

if (isset($_POST['submit'])){

  

}

 
?>
	
?>
<form action="index.php" method="post">

   <input type="text" name="text">
   <input type="submit" name="submit" value="submit">

</form>

